class NodoArbol {
    int dato;
    NodoArbol izquierda;
    NodoArbol derecha;

    public NodoArbol(int dato) {
        this.dato = dato;
        this.izquierda = null;
        this.derecha = null;
    }
}

class Arbol {
    NodoArbol raiz;

    public Arbol() {
        raiz = null;
    }

    // Método para insertar un nuevo nodo en el árbol
    public void insertar(int dato) {
        raiz = insertarRecursivamente(raiz, dato);
    }

    private NodoArbol insertarRecursivamente(NodoArbol actual, int dato) {
        if (actual == null) {
            return new NodoArbol(dato);
        }
        if (dato < actual.dato) {
            actual.izquierda = insertarRecursivamente(actual.izquierda, dato);
        } else if (dato > actual.dato) {
            actual.derecha = insertarRecursivamente(actual.derecha, dato);
        }
        return actual;
    }
    // Método para realizar un recorrido inorden (in-order traversal) del árbol
    public void recorridoInorden(NodoArbol nodo) {
        if (nodo != null) {
            recorridoInorden(nodo.izquierda);
            System.out.print(nodo.dato + " ");
            recorridoInorden(nodo.derecha);
        }
    }
    public int contarNodos() {
        return contarNodosRecursivamente(raiz);
    }

    private int contarNodosRecursivamente(NodoArbol nodo) {
        if (nodo == null) {
            return 0;
        }

        int izquierda = contarNodosRecursivamente(nodo.izquierda);
        int derecha = contarNodosRecursivamente(nodo.derecha);

        return 1 + izquierda + derecha;
    }

    public static void main(String[] args) {
        Arbol arbol = new Arbol();
        // Insertar nodos en el árbol
        arbol.insertar(50);
        arbol.insertar(30);
        arbol.insertar(20);
        arbol.insertar(40);
        arbol.insertar(70);
        System.out.println("Árbol ordenado (recorrido inorden):");
        arbol.recorridoInorden(arbol.raiz);
        int numeroDeNodos = arbol.contarNodos();
        System.out.print("\nNúmero de nodos en el árbol: " + numeroDeNodos);


    }

}
