import java.util.LinkedList;
import java.util.Queue;

class Nodo {
    int valor;
    Nodo izquierdo;
    Nodo derecho;

    public Nodo(int valor) {
        this.valor = valor;
        izquierdo = null;
        derecho = null;
    }
}

class ArbolBinario {
    Nodo raiz;

    public ArbolBinario() {
        raiz = null;
    }

    public LinkedList<Nodo> nodosAltura(int h) {
        LinkedList<Nodo> nodos = new LinkedList<>();
        if (raiz == null || h < 0) {
            return nodos;
        }

        Queue<Nodo> cola = new LinkedList<>();
        cola.offer(raiz);
        int alturaActual = 0;

        while (!cola.isEmpty()) {
            int nodosEnNivel = cola.size();

            for (int i = 0; i < nodosEnNivel; i++) {
                Nodo nodo = cola.poll();

                if (alturaActual == h && (nodo.izquierdo != null || nodo.derecho != null)) {
                    nodos.add(nodo);
                }

                if (nodo.izquierdo != null) {
                    cola.offer(nodo.izquierdo);
                }

                if (nodo.derecho != null) {
                    cola.offer(nodo.derecho);
                }
            }

            alturaActual++;

            if (alturaActual > h) {
                break;
            }
        }

        return nodos;
    }

    public void imprimirArbolOrdenado() {
        imprimirArbolOrdenadoRecursivo(raiz, 0);
    }

    private void imprimirArbolOrdenadoRecursivo(Nodo nodo, int nivel) {
        imprimirArbolHorizontalRecursivo(raiz, "");
    }

    private void imprimirArbolHorizontalRecursivo(Nodo nodo, String prefijo) {
        if (nodo != null) {
            boolean esUltimo = (nodo.derecho == null && nodo.izquierdo == null);

            System.out.println(prefijo + (esUltimo ? "└── " : "├── ") + nodo.valor);

            if (nodo.izquierdo != null || nodo.derecho != null) {
                imprimirArbolHorizontalRecursivo(nodo.izquierdo, prefijo + (esUltimo ? "    " : "│   "));
                imprimirArbolHorizontalRecursivo(nodo.derecho, prefijo + (esUltimo ? "    " : "│   "));
            }
        }
    }
}