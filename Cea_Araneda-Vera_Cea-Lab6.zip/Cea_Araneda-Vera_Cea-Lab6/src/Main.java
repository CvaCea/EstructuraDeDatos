import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.raiz = new Nodo(1);
        arbol.raiz.izquierdo = new Nodo(2);
        arbol.raiz.derecho = new Nodo(3);
        arbol.raiz.izquierdo.izquierdo = new Nodo(4);
        arbol.raiz.izquierdo.derecho = new Nodo(5);
        arbol.imprimirArbolOrdenado();
        int altura = 1;
        LinkedList<Nodo> nodosAltura = arbol.nodosAltura(altura);

        System.out.println("Nodos a altura " + altura + ": ");
        for (Nodo nodo : nodosAltura) {
            System.out.print(nodo.valor + " ");
        }
        System.out.println();
        ArbolBinario arbol1 = new ArbolBinario();
        arbol1.raiz = new Nodo(1);
        arbol1.raiz.izquierdo = new Nodo(2);
        arbol1.raiz.derecho = new Nodo(3);
        arbol1.raiz.izquierdo.izquierdo = new Nodo(4);
        arbol1.raiz.izquierdo.derecho = new Nodo(5);
        arbol1.raiz.derecho.izquierdo = new Nodo(6);
        arbol1.raiz.derecho.derecho = new Nodo(7);
        arbol1.raiz.izquierdo.izquierdo.izquierdo = new Nodo(8);
        arbol1.raiz.izquierdo.izquierdo.derecho = new Nodo(9);
        arbol1.raiz.derecho.derecho.izquierdo = new Nodo(10);
        arbol1.raiz.derecho.derecho.derecho = new Nodo(11);
        arbol1.imprimirArbolOrdenado();
        int altura1 = 2;
        LinkedList<Nodo> nodosAltura1 = arbol1.nodosAltura(altura1);

        System.out.println("Nodos a altura " + altura1 + ": ");
        for (Nodo nodo : nodosAltura1) {
            System.out.print(nodo.valor + " ");
    }
        System.out.println();
}
}
