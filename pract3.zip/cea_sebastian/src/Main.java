import java.util.ArrayList;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Nodo> arr = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            arr.add(new Nodo(nroRandom(),arr[i+1]));
        }
        mostrarLista(arr);
        ordenarLista(arr);
        mostrarLista(arr);

    }

    public static int nroRandom() {
        int i = (int)(Math.random() * 10);
        return i;
    }

    public static void mostrarLista(ArrayList<Nodo> arr) {
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(i + " elemento: " + arr.get(i).nro + " y siguiente es: " + arr.get(i).siguiente);
        }
    }
    public static void ordenarLista(ArrayList<Nodo> lista) {
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (lista.get(j).nro > lista.get(j + 1).nro) {
                    // Intercambiar los nodos si están en el orden incorrecto
                    Nodo temp = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, temp);}
            }
        }
    }
}