public class Nodo {
    int nro;
    Nodo siguiente;

    public Nodo(int nro, Nodo siguiente) {
        this.nro = nro;
        this.siguiente = siguiente;
    }

    public Nodo(int nro) {
        this.nro = nro;
        this.siguiente=null;
    }
//Gs & Ss
    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}
