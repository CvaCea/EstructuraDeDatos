
public class Main {
    public static void main(String[] args) {
        Solucion solucion = new Solucion();

        int n1 = 2;
        int[][] trustej1 = {{1,2}};
        System.out.println(solucion.findJudge(n1, trustej1));
        int n2= 3;
        int[][] trustej2 = {{1,3},{2,3}};
        System.out.println(solucion.findJudge(n2,trustej2));
        int n3= 3;
        int[][] trustej3 = {{1,3},{2,3},{3,1}};
        System.out.println(solucion.findJudge(n3,trustej3));

        int n4= 3;
        int[][] trustej4 = {{1,3},{2,3},{3,1},{4,3}};
        System.out.println(solucion.findJudge(n3,trustej4));


        int n0 = 1;
        int[][] trustej0 = new int[0][0];
        System.out.println(solucion.findJudge(n0,trustej0));

    }
}