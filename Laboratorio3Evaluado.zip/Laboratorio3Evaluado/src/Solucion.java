import java.util.*;
class Solucion {
    public String findJudge(int n, int[][] trust) {
        if (trust.length == 0 && n == 1) {
            String salida1 = "no hay suficientes lazos de confianza";
            return salida1;
        }

        Map<Integer, List<Integer>> graph = new HashMap<>();
        int[] trusts = new int[n + 1];

        for (int[] pair : trust) {
            int a = pair[0];
            int b = pair[1];
            graph.computeIfAbsent(a, k -> new ArrayList<>()).add(b);
            trusts[b]++;
        }

        for (int i = 1; i <= n; i++) {
            if (trusts[i] == n - 1 && !graph.containsKey(i)) {
                String salida2 = i+"";
                return salida2;

            }
        }
        String seEscapo = "Se escapo";
        return seEscapo;
    }
}
