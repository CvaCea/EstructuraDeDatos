
package com.mycompany.cea_sebastian_lab2;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Cea_Sebastian_Lab2 {

	public static int[] fillArray(int n) {
		int[] array = new int[n];
		Random rnd = new Random();
		for (int i = 0; i < array.length; i++) {
			array[i] = rnd.nextInt(n * 10);
		}
		return array;
	}

	public static void bubbleSort(int array[]) {
		int n = array.length;
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				if (array[j] > array[j + 1]) {
					// swap arr[j+1] and arr[j]
					int temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
				}
			}
		}
	}

	public static void merge(int array[], int l, int m, int r) {
		// Find sizes of two subarrays to be merged
		int n1 = m - l + 1;
		int n2 = r - m;

		/* Create temp arrays */
		int L[] = new int[n1];
		int R[] = new int[n2];

		/* Copy data to temp arrays */
		for (int i = 0; i < n1; ++i)
			L[i] = array[l + i];
		for (int j = 0; j < n2; ++j)
			R[j] = array[m + 1 + j];

		/* Merge the temp arrays */

		// Initial indexes of first and second subarrays
		int i = 0, j = 0;

		// Initial index of merged subarray array
		int k = l;
		while (i < n1 && j < n2) {
			if (L[i] <= R[j]) {
				array[k] = L[i];
				i++;
			} else {
				array[k] = R[j];
				j++;
			}
			k++;
		}

		/* Copy remaining elements of L[] if any */
		while (i < n1) {
			array[k] = L[i];
			i++;
			k++;
		}

		/* Copy remaining elements of R[] if any */
		while (j < n2) {
			array[k] = R[j];
			j++;
			k++;
		}
	}

	// Main function that sorts arr[l..r] using
	// merge()
	public static void sort(int array[], int l, int r) {
		if (l < r) {
			// Find the middle point
			int m = l + (r - l) / 2;

			// Sort first and second halves
			sort(array, l, m);
			sort(array, m + 1, r);

			// Merge the sorted halves
			merge(array, l, m, r);
		}
	}
	
	public static void mergeSort(int array[]) {
		sort(array, 0, array.length - 1);
	}
	
	public static void print(int array[]) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
            long arr[][]=new long[9][3];
            imprimirMatriz(arr);
            System.out.println("Se ve que con tamaño 50 000 se demora levemente, mientras que con 100 000 un poco más y en 50 000 000 se demora mucho ");
            
	}
        public static long[] testeo(int n) {
            long auxA = 0, auxB = 0, auxC = 0;
            for (int i = 0; i < 2; i++) {
                int arr_1[] = fillArray(n);
                int arr_2[] = arr_1.clone();
                int arr_3[] = arr_1.clone();
                if (n >= 1000000) {
                    long startTime = System.nanoTime();
                    mergeSort(arr_2);
                    long finishTime = System.nanoTime() - startTime;
                    finishTime = System.nanoTime() - startTime;
                   // System.out.println("Merge Sort: " + finishTime + " ns");
                    auxB += finishTime;

                    startTime = System.nanoTime();
                    Arrays.sort(arr_3);
                    finishTime = System.nanoTime() - startTime;
                   // System.out.println("Java Sort: " + finishTime + " ns");
                    auxC += finishTime;
                } else {
                    long startTime = System.nanoTime();
                    bubbleSort(arr_1);
                    long finishTime = System.nanoTime() - startTime;
                    //System.out.println("Bubble Sort: " + finishTime + " ns");
                    auxA += finishTime;

                    startTime = System.nanoTime();
                    mergeSort(arr_2);
                    finishTime = System.nanoTime() - startTime;
                    //System.out.println("Merge Sort: " + finishTime + " ns");
                    auxB += finishTime;

                    startTime = System.nanoTime();
                    Arrays.sort(arr_3);
                    finishTime = System.nanoTime() - startTime;
                   // System.out.println("Java Sort: " + finishTime + " ns");
                    auxC += finishTime;
                }
            }
            auxA /= 2;
            auxB /= 2;
            auxC /= 2;
            return new long[] { auxA, auxB, auxC };
}

        public static void imprimirMatriz(long[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;
        int i;
        System.out.printf(" %1s %25s %25s %25s %n","Tamaño","Bubble sort","Mergue sort","Java sort");
        /*String encabezado[]={"Tamaño","Bubble sort","Mergue sort","Java sort"};
        for (i=0;i<encabezado.length;i++){
            System.out.print(encabezado[i]+"\t\t");}
            System.out.println();*/
        for ( i = 0; i < filas; i++) {
            int var=0;
            switch(i){
                case 0 :
                    System.out.print("1 000");
                    var=1000;
                    break;
                case 1 : System.out.print("5 000");
                    var=5000;
                    break;
                case 2 :
                    System.out.print("10 0000");
                    var=10000;
                    break;
                case 3 : 
                    System.out.print("50 0000");
                    var=50000;
                    break;
                case 4 : 
                    System.out.print("100 0000");
                    var=100000;
                    break;
                case 5 :
                    System.out.print("1 000 0000");
                    var=1000000;
                    break;
                case 6 : 
                    System.out.print("5 000 0000");
                    var=5000000;
                    break;
                case 7 : 
                    System.out.print("10 000 000");
                    var=10000000;
                    break;
                case 8 :
                    System.out.print("50 000 0000");
                    var=50000000;
                    break;
                default:break;
            } imprimeFila(testeo(var));
            }
            System.out.println();
        }
        public static void imprimeFila(long arr[]){
            for(int i=0;i<arr.length;i++){
                System.out.printf("%25s",arr[i]);}
            System.out.println();
        }
    }

