public class ListaEnlazada {
    Nodo cabeza;

    public ListaEnlazada() {
        this.cabeza = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
    public void ordenarLista() {
        if (cabeza == null) {
            // La lista está vacía, no hay nada que ordenar
            return;
        }

        boolean intercambio;
        do {
            intercambio = false;
            Nodo actual = cabeza;
            Nodo siguiente = cabeza.siguiente;
            Nodo anterior = null;

            while (siguiente != null) {
                if (actual.dato > siguiente.dato) {
                    // Realizar el intercambio de nodos
                    if (anterior != null) {
                        anterior.siguiente = siguiente;
                    } else {
                        cabeza = siguiente;
                    }
                    actual.siguiente = siguiente.siguiente;
                    siguiente.siguiente = actual;

                    // Actualizar los punteros
                    anterior = siguiente;
                    siguiente = actual.siguiente;

                    intercambio = true;
                } else {
                    anterior = actual;
                    actual = siguiente;
                    siguiente = siguiente.siguiente;
                }
            }
        } while (intercambio);
    }





}
