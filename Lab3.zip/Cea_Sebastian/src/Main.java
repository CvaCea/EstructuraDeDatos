public class Main {

    public static void main(String[] args) {
        ListaEnlazada lista = new ListaEnlazada();

        // Agregar 10 elementos a la lista
        for (int i = 1; i <= 10; i++) {
            lista.agregarElemento(nroRandom());
        }

        // Imprimir la lista
        lista.imprimirLista();
        lista.ordenarLista();
        lista.imprimirLista();
    }
    public static int nroRandom(){
        int a=(int)(Math.random()*100);
        return a;
    }



}